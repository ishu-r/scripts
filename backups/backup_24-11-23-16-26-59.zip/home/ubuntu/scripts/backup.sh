#!/bin/bash

<< readme
This script takes backup of given directory
./backup.sh <path of directory> <path of backup directory>
readme

source_dir=$1

target_dir=$2

timestamp=$(date '+%y-%m-%d-%H-%M-%S')

backup_dir="${target_dir}/backup_${timestamp}"
function create_backup() {
zip -r "${backup_dir}.zip" "${source_dir}"



if [ $? -eq 0 ]; then
	echo "Backup created successfully"
else
	echo "Backup not created successfully $timestamp"
fi
}


create_backup
